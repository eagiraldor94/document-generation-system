<?php

namespace ludcis\Http\Controllers;

use Illuminate\Http\Request;

use QrCode;

class ControladorPruebas extends Controller
{
    //
}
