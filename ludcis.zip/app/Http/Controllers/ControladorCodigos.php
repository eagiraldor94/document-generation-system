<?php

namespace ludcis\Http\Controllers;

use Illuminate\Http\Request;

class ControladorCodigos extends Controller
{
    //
}
