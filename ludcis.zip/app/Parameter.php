<?php

namespace ludcis;

use Illuminate\Database\Eloquent\Model;

class Parameter extends Model
{
    //
}
