<?php

namespace ludcis;

use Illuminate\Database\Eloquent\Model;

class ProductForSearch extends Model
{
	protected $table = "products_for_search";
}
