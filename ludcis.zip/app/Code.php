<?php

namespace ludcis;

use Illuminate\Database\Eloquent\Model;

class Code extends Model
{
    //
}
