
  <!-- Navbar -->
  <header class="main-header">
    
  <nav class="main-header navbar navbar-expand bg-light navbar-light border-bottom">
    <!-- Left navbar links -->
    <div class="container">
      <a href="index3.html" class="navbar-brand">
        <img src="/Views/img/plantilla/LOGO_PRINCIPAL_peq.jpg" alt="Logo" class="brand-image img-circle elevation-3"
             style="opacity: .8">
        <span class="brand-text font-weight-light">ludcis</span>
      </a>
      <ul class="navbar-nav">
        <li class="nav-item d-none d-sm-inline-block">
          <a href="https://ludcis.com/documentos" class="nav-link">Documentos</a>
        <li>
      </ul>
    </div>
  </nav>
  </header><!-- /header -->
  <!-- /.navbar --><?php /**PATH C:\laragon\www\ludcis\resources\views/layouts/menu.blade.php ENDPATH**/ ?>