<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        
    </div>
    <!-- Default to the left -->
    Al utilizar la plataforma <strong><a style="color: #555" href="https://ludcis.com" target="_blank">LUDCIS S.A.S.</a></strong> usted acepta los <strong><a style="color: #555" href="https://ludcis.com/terminos-y-condiciones" target="_blank">Términos y Condiciones</a></strong> y nuestra <strong><a style="color: #555" href="https://ludcis.com/politica-privacidad" target="_blank">Política de privacidad</a></strong> | Todos los derechos reservados.
</footer><?php /**PATH C:\laragon\www\ludcis\resources\views/layouts/footer.blade.php ENDPATH**/ ?>