$( function() {
    $( ".datepicker" ).datepicker({ format: 'dd/mm/yyyy',autoclose: true,language:'es' });
  } );