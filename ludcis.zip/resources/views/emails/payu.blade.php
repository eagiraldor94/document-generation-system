@extends('emails.mail')
@section('body')
<div class="row">
	{{var_dump($post)}}

</div>
@stop